from paytmApi_v2 import app

if __name__ == "__main__":
    app.run()

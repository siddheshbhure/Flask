import psycopg2
import flask
from flask import request, jsonify
from psycopg2.pool import ThreadedConnectionPool
from config import config
from contextlib import contextmanager
import datetime

app = flask.Flask(__name__)
app.config["DEBUG"] = False
params = config()
dbConnection = "dbname='{}' user='{}' host='{}' password='{}'".format(params['database'],params['user'],params['host'],params['password'])
#print(params['minconnection'])
connectionpool = ThreadedConnectionPool(int(params['minconnection']),int(params['maxconnection']),dsn=dbConnection)
#connectionpool = SimpleConnectionPool(1,50,dsn=dbConnection)
@contextmanager
def getcursor():
    con = connectionpool.getconn()
    try:
        yield con.cursor()
    finally:
        connectionpool.putconn(con)

@app.route('/', methods=['GET'])
def home():
    return '''<h1>PaytmAPI Test</p>'''

@app.route('/loanDetails', methods=['POST']) 
def connect():
    result=''
    x=datetime.datetime.now()
    req=request.json
    try:
        with getcursor() as cur:
            cur.execute("SET search_path TO " + params['schema'])
            cur.execute('SELECT LOAN_ACCOUNT_NUMBER,CUSTOMER_NAME,TOTAL_OVERDUE_AMOUNT,EMI_OVERDUE,PENAL_INTEREST,EMI_AMOUNT,OVERDUE_CHARGES from "PAYTM_MASTER_TABLE" where trim(LOAN_ACCOUNT_NUMBER)=\'{}\' limit 1'.format(req['loanAccountNumber']).strip())
            row = cur.fetchone()

            if(cur.rowcount>0):
                    result={}
                    result['loanAccountNumber']=(str(row[0]).strip())
                    result['customerName']=str(row[1]).strip()
                    result['totalOverdueAmount']=str(row[2]).strip()
                    result['emiOverdue']=str(row[3]).strip()
                    result['additionalInterest']=str(row[4]).strip()
                    result['info']='Success'
                    #result['additionalInterest']=''
                    result['emiAmount']=str(row[5]).strip()
                    result['overdueCharges']=str(row[6]).strip()
                    result['status']='Success'

            else:
                result={}
                result['loanAccountNumber']=(req['loanAccountNumber']).strip()
                result['info']='No Details found for the mentioned Account'
                result['status']='Failure'
        print(result['loanAccountNumber']+'|'+str(x)+'|'+str(datetime.datetime.now()))
        return jsonify(result)
        
    except (Exception, psycopg2.DatabaseError) as error:
        result={}
        print(error)
        result['loanAccountNumber']=(req['loanAccountNumber']).strip()
        result['info']= str(error)
        result['status']='Error'
        return jsonify(result)
        #print(error)
app.run(host='0.0.0.0')
